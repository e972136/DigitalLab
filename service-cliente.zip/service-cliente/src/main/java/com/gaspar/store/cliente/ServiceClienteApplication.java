package com.gaspar.store.cliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceClienteApplication.class, args);
	}

}
